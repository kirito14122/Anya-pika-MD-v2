<div align="center">
  
## 𝐀𝖓𝐲𝖆 𝖇𝐲 𝕻𝖎𝖐𝖆𝖈𝖍𝖚
##   
<p align="center">
<img src="./HomeScreen/Anyapic.jpg" alt="Pika" height= "244.5" width="300"/>


</p>
<p align="center">
<a href="#"><img title="𝐐𝐔𝚵𝚵𝚴 𝚫𝚴𝐘𝚫 𝐦𝐮𝐥𝐭𝐢 𝐝𝐞𝐯𝐢𝐜𝐞." src="https://img.shields.io/badge/𝐐𝐔𝚵𝚵𝚴 𝚫𝚴𝐘𝚫 𝐦𝐮𝐥𝐭𝐢 𝐝𝐞𝐯𝐢𝐜𝐞.-red?colorA=%23ff0000&colorB=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Pika4O4"><img title="Author" src="https://img.shields.io/badge/Author-Pika4O4-red.svg?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/Pika4O4/Anya-pika-MD-v2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Pika4O4/Anya-pika-MD-v2?color=blue&style=flat-square"></a>
<a href="https://github.com/Pika4O4/Anya-pika-MD-v2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Pika4O4/Anya-pika-MD-v2?color=red&style=flat-square"></a>
<a href="https://github.com/Pika4O4/Anya-pika-MD-v2/"><img title="Size" src="https://img.shields.io/github/repo-size/Pika4O4/Anya-pika-MD-v2?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FPika4O4%2Anya-pika-MD-v2&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/Pika4O4/Anya-pika-MD-v2/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</P>
</div>

<p align="center"><img src="https://profile-counter.glitch.me/{Pika}/count.svg" alt="Pika :: Visitor's Count" /></p>

ㅤ
ㅤ
### DEPLOY THROUGH HEROKU

<a href="https://heroku.com/deploy?template=https://github.com/Pika4O4/Anya-pika-MD-v2/"><img align="center" src="./HomeScreen/AnyaPikaButtonHeroku.jpg" alt="Fork and deploy" height="65" width="230" /></a>
</div>
ㅤ
ㅤ
 
  
### SCAN QR CODE


<a href="https://replit.com/@DEVILL-MASCOT/ANYA-PIKA-MD2"><img src="./HomeScreen/AnyaQRscan.png" align="center" width="90" />
</div>
<p align="center">
</p>

ㅤ
ㅤ
# Install Manually 👇
## `Requirements`
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)

## `Clone Repo & Installation dependencies`
```bash
git clone https://github.com/Pika4O4/Anya-pika-MD-v2
cd Anya-pika-MD-v2

npm start
```
## `For Termux/Ssh/Ubuntu`
```bash
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/Pika4O4/Anya-pika-MD-v2
cd Anya-pika-MD-v2
npm start
```
## `For VPS`
```bash
apt install nodejs 
apt install git 
apt apt install ffmpeg 
apt apt install libwebp 
apt apt install imagrmagick
apt install bash
git clone https://github.com/Pika4O4/Anya-pika-MD-v2
cd Anya-pika-MD-v2
npm start
```
## `For 24/7 Activation (Termux)`
```bash
npm i -g pm2 && pm2 start nexus.js && pm2 save && pm2 logs
```

## ℂℝ𝔼𝔻𝕀𝕋𝕊
### [Thanks to nexus for help me and gave me base of 𝗫𝗕𝗢𝗧 ✨](https://github.com/NEXUSAT12/XBOT)

### [2n thanks to xeon for base of 𝗖𝗵𝗲𝗲𝗺𝘀𝗕𝗼𝘁 𝘃𝟰 ✨](https://github.com/DGXeon/CheemsBot-MD4)

### [3rd thanks to jetus-hack for making a 𝗽𝗲𝗿𝘀𝗼𝗻𝗮𝗹 𝘄𝗲𝗯𝘀𝗶𝘁𝗲 for anya and encryption the script ✨](https://github.com/jetus-hack)

## 𝑻𝒉𝒆 𝒎𝒂𝒊𝒏 𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒓 𝑷𝒊𝑲𝒂𝑪𝒉𝒖🥵🔥
<p align="center">

<img src="./HomeScreen/Developerpic.jpg"> (https
<br>
<div>
<br>
